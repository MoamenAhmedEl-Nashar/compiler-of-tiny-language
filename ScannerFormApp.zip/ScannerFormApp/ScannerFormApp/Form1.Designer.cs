﻿namespace ScannerFormApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rb_input = new System.Windows.Forms.RichTextBox();
            this.b_Start = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rb_input
            // 
            this.rb_input.Location = new System.Drawing.Point(54, 21);
            this.rb_input.Name = "rb_input";
            this.rb_input.Size = new System.Drawing.Size(238, 170);
            this.rb_input.TabIndex = 0;
            this.rb_input.Text = "";
            // 
            // b_Start
            // 
            this.b_Start.Location = new System.Drawing.Point(140, 222);
            this.b_Start.Name = "b_Start";
            this.b_Start.Size = new System.Drawing.Size(75, 23);
            this.b_Start.TabIndex = 1;
            this.b_Start.Text = "Start";
            this.b_Start.UseVisualStyleBackColor = true;
            this.b_Start.Click += new System.EventHandler(this.b_Start_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 322);
            this.Controls.Add(this.b_Start);
            this.Controls.Add(this.rb_input);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rb_input;
        private System.Windows.Forms.Button b_Start;
    }
}

