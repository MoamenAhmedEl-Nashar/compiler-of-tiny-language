﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScannerFormApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
        private void inputChecker(string code)
        {
            string id;
            for(int i=0; i<code.Length; i++)
            {
                if(char.IsLetter(code[i]))
                {
                    
                }
            }
        }

        private void b_Start_Click(object sender, EventArgs e)
        {
            string code = rb_input.Text.ToString();
        }
    }
}
