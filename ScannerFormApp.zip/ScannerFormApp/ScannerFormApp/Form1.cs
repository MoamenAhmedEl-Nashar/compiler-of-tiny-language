﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ScannerFormApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string path;

        public List<string> values = new List<string>();
        public List<string> types = new List<string>();

        private bool isSymbol(char str)
        {
            if (str == '+' || str == '-' ||
               str == '*' || str == '/' ||
               str == '=' || str == '<' ||
               str == '(' || str == ')' ||
               str == ';')
                return true;
            else return false;
        }

        private bool isReserved(string str)
        {
            if (str == "if" || str == "then" || str == "else" ||
               str == "end" || str == "repeat" || str == "until" ||
               str == "read" || str == "write")
                return true;
            else return false;
        }


        private void scanner(string code)
        {
            int state = 0;
            string current_string = "";
            var builder = new StringBuilder();
            int i = 0;
            while (i < code.Length)
            {
                switch (state)
                {
                    case 0://start
                        if (code[i] == ' ' || code[i] == '\n')
                        {
                            state = 0;
                            i++;
                        }
                        else if (code[i] == '{')
                        {
                            state = 1;
                            i++;
                        }
                        else if (isSymbol(code[i]))
                        {
                            builder.Append(code[i]);
                            current_string = builder.ToString();
                            values.Add(current_string);
                            types.Add("symbol");
                            current_string = "";
                            builder.Clear();
                            state = 0;
                            i++;
                        }
                        else if (char.IsDigit(code[i]))
                        {
                            builder.Append(code[i]);
                            current_string = builder.ToString();
                            state = 2;//number
                            i++;
                        }
                        else if (char.IsLetter(code[i]))
                        {
                            builder.Append(code[i]);
                            current_string = builder.ToString();
                            state = 3;//id
                            i++;
                        }
                        else if (code[i] == ':')
                        {
                            builder.Append(code[i]);
                            current_string = builder.ToString();
                            state = 4;//assign
                            i++;
                        }
                        break;

                    case 1://comment
                        if (code[i] != '}')
                        {
                            state = 1;//comment
                            i++;
                        }
                        else
                        {
                            state = 0;//start
                            i++;
                        }
                        break;
                    case 2://number
                        if (char.IsDigit(code[i]))
                        {
                            builder.Append(code[i]);
                            current_string = builder.ToString();
                            state = 2;
                            i++;
                        }
                        else
                        {
                            values.Add(current_string);
                            types.Add("number");
                            current_string = "";
                            builder.Clear();
                            state = 0;
                        }
                        break;
                    case 3://id
                        if (char.IsLetterOrDigit(code[i]))
                        {
                            builder.Append(code[i]);
                            current_string = builder.ToString();
                            state = 3;
                            i++;
                        }
                        else
                        {
                            values.Add(current_string);
                            if (isReserved(current_string))
                            {
                                types.Add("reserved");
                            }
                            else
                            {
                                types.Add("identifier");
                            }
                            current_string = "";
                            builder.Clear();
                            state = 0;
                        }
                        break;
                    case 4://assign
                        if (code[i] == '=')
                        {
                            builder.Append(code[i]);
                            current_string = builder.ToString();
                            values.Add(current_string);
                            types.Add("symbol");
                            current_string = "";
                            builder.Clear();
                            state = 0;
                            i++;
                        }
                        break;
                }
            }
        }

        private void b_browse_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                path = openFileDialog1.FileName;
            }
        }

        private void b_Start_Click(object sender, EventArgs e)
        {
            string code = rb_input.Text.ToString();
            scanner(code);

            for(int i=0; i<values.Count; i++)
            {
                flp_values.Controls.Add(new Label { Name = "lb_value", Text = values[i]});
                flp_types.Controls.Add(new Label { Name = "lb_type" , Text = types[i] });
                groupBox2.Controls.Add(flp_values);
                groupBox2.Controls.Add(flp_types);
            }

            TextWriter tw = new StreamWriter(path);

            for(int i=0; i<values.Count; i++)
            {
                string s = values[i] + "     " + types[i];
                tw.WriteLine(s);
            }

            tw.Close();

        }

        private void ScorePanel_Scroll(object sender, ScrollEventArgs e)
        {
            var senderPanel = sender as FlowLayoutPanel;

            if (senderPanel == null)
            {
                // Might want to print to debug or mbox something, because this shouldn't happen.
                return;
            }

            var otherPanel = senderPanel == flp_values ? flp_types : flp_values;

            otherPanel.VerticalScroll.Value = senderPanel.VerticalScroll.Value;
        }

        private void flp_values_Paint(object sender, PaintEventArgs e)
        {
            flp_values.Scroll += ScorePanel_Scroll;
            flp_types.Scroll += ScorePanel_Scroll;
        }

        private void flp_types_Paint(object sender, PaintEventArgs e)
        {
            flp_values.Scroll += ScorePanel_Scroll;
            flp_types.Scroll += ScorePanel_Scroll;
        }
    }
}
